# Blitzed-Grabber-fixed'

Download
Extract to desktop
Run "Kyanite.exe" 
